export class Restaurant {
    _id: string;
    Name: string;
    Rating:String;
    Url:String;
    Info:String;
    Timings:String;
    officialurl:String;
    review:[];
}