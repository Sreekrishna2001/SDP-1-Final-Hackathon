const { List } = require('./Restaurants.model');
const { Task} = require('./Review.model');
const { User } = require('./user.model');


module.exports = {
    List,
    Task,
    User
}