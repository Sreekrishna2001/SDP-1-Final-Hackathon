# B4EAT



##### The B4EAT is a basic Web Application made with MongoDB, Express, Angular and NodeJS which allows users to do basic things like LOGIN, SIGNUP and main features include to Review a particular Restaurant that exists in the B4EAT's database list 
>you have to install all server dependencies using npm i 
>after installing all the dependencies you have to run server using npm start and it will host on port which is givn in process env variable
> Don't forget to run `npm install` in both the **api** and **frontend** folders to install dependencies
> To run the project we need to click ng serve.
>Next we want to open localhost:4200 in your browser.

