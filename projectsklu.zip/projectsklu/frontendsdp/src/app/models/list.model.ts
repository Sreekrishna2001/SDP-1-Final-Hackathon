export class List {
    _id: string;
    title: string;
}